package dominio3;

public enum GenerosTeatro {
	Drama, Teatro, Comedia
}
