package dominio3;

public enum TipoEntradaRecital {

	General, VIP
}
