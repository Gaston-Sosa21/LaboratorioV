package dominio3;

public enum TiposEntradaDeporte {

	Futbol, Rugby, Hockey
}
