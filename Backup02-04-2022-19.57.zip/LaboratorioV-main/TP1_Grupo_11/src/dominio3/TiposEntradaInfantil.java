package dominio3;

public enum TiposEntradaInfantil {
	
	Mayor8, Menor8
}
