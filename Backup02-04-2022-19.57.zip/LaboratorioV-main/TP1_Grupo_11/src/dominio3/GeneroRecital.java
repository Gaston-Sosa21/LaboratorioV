package dominio3;

public enum GeneroRecital {
	Rock, Heavy_metal, Reggaeton, Trap, Latinos, Pop
}
