package dominio3;

public interface IPrecioEntrada {

	public float calcularPrecio();
}
